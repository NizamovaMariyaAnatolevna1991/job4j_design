package ru.job4j.generics;

public class Animal {
}
