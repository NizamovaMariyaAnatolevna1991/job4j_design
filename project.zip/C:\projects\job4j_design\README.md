job4j.ru - Блок Структуры данных и алгоритмы

   2.1.0. Maven
   2.1.1. AssertJ
   2.1.2. Iterator
   2.1.3. Generic
   2.1.4. List
   2.1.5. Set
   2.1.6. Map
   2.1.7. Tree